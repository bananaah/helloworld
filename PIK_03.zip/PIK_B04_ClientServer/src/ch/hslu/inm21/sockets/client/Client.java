package ch.hslu.inm21.sockets.client;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class Client {

	public static void main(String[] args) throws IOException {

		Socket socket;
		InetAddress addr = InetAddress.getByName("192.168.1.115");

		System.out.println("Start.");

		socket = new Socket(addr, 10018);
		System.out.println("Verbindung hergestelllt.");

		// Testmeldung senden
		System.out.println("Testmeldung senden.");
		OutputStream os = socket.getOutputStream();
		String msg = "Hoiii!";
		os.write(msg.getBytes());

		// Socket schliessen
		socket.close();
		
		System.out.println("Nachricht gesendet.");

	}

}
